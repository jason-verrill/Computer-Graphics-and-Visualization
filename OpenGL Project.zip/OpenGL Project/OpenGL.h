#ifndef OPENGL_H_
#define OPENGL_H_

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdexcept>

#include "stb_image.h"
#include "BasicShape.h"
#include "Camera.h"
#include "light.h"

class OpenGL {
public:
	// Constructors and Deconstructors
	OpenGL();
	~OpenGL();

	// Public use functions
	int Initialize(int windowWidth, int windowHeight);
	int Run();

	static void framebuffer_size_callback(GLFWwindow* window, int width, int height);

private:
	// Function return values for internal use
	enum RESULT {
		SUCCESS = 1,
		FAIL = 0
	};

	// Private variables
	bool isInitialized;
	GLFWwindow* window;
	unsigned int vertexArray[2];
	unsigned int vertexBuffer[2];
	unsigned int elementBuffer[2];
	unsigned int shaderProgram[2];
	int numShaders;
	std::string logOutput;
	int numIndices;
	unsigned int transformLocation;
	unsigned int projectionLocation;
	unsigned int viewLocation;
	glm::mat4 transform;
	glm::mat4 view;
	glm::mat4 projection;
	float deltaTime;
	float lastFrame;
	float lastMouseX;
	float lastMouseY;
	bool firstCamUpdate;
	bool projectionType;

	// Shader uniform variables
	unsigned int lightViewLocation;
	unsigned int lightProjectionLocation;
	unsigned int lightTransformLocation;
	unsigned int camPositionLocation;
	unsigned int lightVAO;
	unsigned int lightColorLocation;

	unsigned int lightPositionLocation[3];
	unsigned int lightDirectionLocation[3];
	unsigned int lightAmbientLocation[3];
	unsigned int lightDiffuseLocation[3];
	unsigned int lightSpecularLocation[3];
	unsigned int lightConstantLocation[3];
	unsigned int lightLinearLocation[3];
	unsigned int lightQuadratic[3];


	// Camera object
	Camera camera;

	// Manually created basic shapes (see BasicShape.h and BasicShape.cpp)
	BasicShape triangle[2];
	BasicShape rectangle[3];
	BasicShape pyramid[1];
	BasicShape pencil[4];
	BasicShape plane[1];
	BasicShape testObject;
	BasicShape newPencil[1];
	BasicShape cube[2];
	BasicShape pencilTip;
	BasicShape pencilBody;
	BasicShape pencilClip;
	BasicShape pencilFerrule;
	BasicShape pencilEraser;
	BasicShape deskOrganizerLip;
	BasicShape deskOrganizerInsert;
	BasicShape chargerBank;
	BasicShape cupLip;
	BasicShape cupBody;



	Light light[3];


	// Private internal functions
	void charArrayToString(char *charArray, int size);
	void setupWindow(int winWidth, int winHeight);
	std::string readFile(const char* filepath);
	void setupShaders(const char* vsFilepath, const char* fsFilepath);
	void getShaderVariables();
	void createManualShapes();
	void processInput(GLFWwindow* window);
	void setupCamera();
	void resetTransform();
	void updateTime();
	void setupLightShaders();
	void updateLights();
	void createLights();

};

#endif