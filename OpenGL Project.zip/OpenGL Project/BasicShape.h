#ifndef BASICSHAPE_H_
#define BASICSHAPE_H_

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>
#include <iostream>

#include "stb_image.h"

class BasicShape {
public:
	void createShape(std::vector<float> vertexData, std::vector<unsigned int> indexData, unsigned int transformShaderLocation, glm::mat4 & transformMatrix);
	void setPosition(float x, float y, float z);
	void setRotation(float degrees, float x, float y, float z);
	void setScale(float x, float y, float z);
	void setModelSpace(unsigned int transformShaderLocation, glm::mat4* transformMatrix);
	void addTexture(const char* filename, unsigned int startingIndexLocation=0);
	void addMaterial(unsigned int shaderProgram, glm::vec3 ambientLight, glm::vec3 diffuseLight, glm::vec3 specularLight, float objectShininess);
	void draw();

private:
	struct Material {
		glm::vec3 ambient;
		glm::vec3 diffuse;
		glm::vec3 specular;
		float shininess;

		unsigned int ambientLocation;
		unsigned int diffuseLocation;
		unsigned int specularLocation;
		unsigned int shininessLocation;
	};

	unsigned int vertexArray;
	unsigned int vertexBuffer;
	unsigned int elementBuffer;
	unsigned int transformLocation;
	unsigned int shaderProgram;
	std::vector<float> vertices;
	std::vector<unsigned int> indices;
	glm::mat4 rotation;
	glm::mat4 position;
	glm::mat4 scale;
	glm::mat4 * transform;
	Material material;
	bool hasMaterial;
	bool hasTexture;
	std::vector<unsigned int> textures;
	std::vector<unsigned int> textureIndexOffset;
};

#endif