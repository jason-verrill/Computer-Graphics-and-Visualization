#include "OpenGL.h"
#include <iostream>

int main() {
	// Initialize dynamic memory for a custom OpenGL class (see OpenGL.h and OpenGL.cpp)
	OpenGL* engine = new OpenGL();
	int winWidth = 800;
	int winHeight = 600;

	// If memory was allocated succesfully...
	if (engine) {
		// Initialize OpenGL and if it succeeds, run the engine
		if (!engine->Initialize(winWidth, winHeight)) {
			std::cout << "Failed to initialize OpenGL" << std::endl;
		}
		else {
			// Enter the window loop
			engine->Run();
		}
	}
	
	// Cleanup
	delete engine;

	return 0;
}