#ifndef CAMERA_H_
#define CAMERA_H_

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>

class Camera {
public:
	Camera();
	glm::mat4 getViewUpdate();
	void updateRotation(float yaw, float pitch);
	void updateTime(float deltaTime);
	void moveForward();
	void moveBackward();
	void moveLeft();
	void moveRight();
	void moveUp();
	void moveDown();
	void increaseSpeed();
	void decreaseSpeed();
	glm::vec3 getPosition();

private:
	glm::mat4 view;
	unsigned int viewLocation;
	glm::vec3 position;
	glm::vec3 forward;
	glm::vec3 up;
	glm::vec3 right;
	float speed;
	float moveAmount;
	float mouseSensitivity;
	float yaw;
	float pitch;
	float maxSpeed;
};

#endif