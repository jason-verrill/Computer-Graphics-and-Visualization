#include "Camera.h"

Camera::Camera() {
	// Initial camera values
	position = glm::vec3(0.0f, 25.0f, 40.0f);
	forward = glm::vec3(0.0f, 0.0f, 1.0f);
	up = glm::vec3(0.0f, 1.0f, 0.0f);
	speed = 0.3f;
	maxSpeed = 0.75f;
	mouseSensitivity = 0.1f;
	yaw = -90.0f;
	pitch = -35.0f;
}

glm::mat4 Camera::getViewUpdate() {
	view = glm::lookAt(
		position,
		position + forward,
		up);

	return view;
};

void Camera::updateRotation(float mouseXChange, float mouseYChange) {
	float maxPitch = 89.0f;

	// Add rotation speed weights
	yaw += mouseXChange * mouseSensitivity;
	pitch -= mouseYChange * mouseSensitivity;


	// Max and minimum pitch
	if (pitch > maxPitch) {
		pitch = maxPitch;
	}
	if (pitch < -maxPitch) {
		pitch = -maxPitch;
	}

	glm::vec3 direction;

	// Calculate proper rotations
	direction.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	direction.y = sin(glm::radians(pitch));
	direction.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));

	forward = glm::normalize(direction);
	
}

void Camera::increaseSpeed() {
	// If increase is called, increase by flat amount
	speed += 0.01f;

	// Set max speed
	if (speed > maxSpeed) {
		speed = maxSpeed;
	}
}

void Camera::decreaseSpeed() {
	// If decrease is called, decrease by flat amount
	speed -= 0.01f;

	// Minimum speed
	if (speed < 0) {
		speed = 0;
	}
}

// Calculate the needed movement difference based on elapsed time for each direction
// Up/Down is halved

void Camera::updateTime(float deltaTime) {
	moveAmount = speed * deltaTime;
}

void Camera::moveForward() {
	position += forward * speed;
}

void Camera::moveBackward() {
	position -= forward * speed;
}

void Camera::moveLeft() {
	// To get left/right we need the cross product of forward and right
	position -= glm::normalize(glm::cross(forward, up)) * speed;
}

void Camera::moveRight() {
	// To get left/right we need the cross product of forward and right
	position += glm::normalize(glm::cross(forward, up)) * speed;
}

void Camera::moveUp() {
	position += up * speed * 0.5f;	// half of other speeds
}

void Camera::moveDown() {
	position -= up * speed * 0.5f;	// half of other speeds
}

glm::vec3 Camera::getPosition() {
	return position;
}