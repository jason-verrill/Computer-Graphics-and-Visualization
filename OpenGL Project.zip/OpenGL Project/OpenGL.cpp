#include "OpenGL.h"

// Globals required for OpenGL callback functions in order to get data to my class
double MOUSE_X_POSITION = 0.0f;
double MOUSE_Y_POSITION = 0.0f;
double MOUSEWHEEL_CHANGE = 0.0f;

// Function called when mouse change is detected
void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
	// Capture mouse position
	MOUSE_X_POSITION = xpos;
	MOUSE_Y_POSITION = ypos;
}

// Function called when mouse scrollwheel is detected
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
	// Detect mousewheel chnage direction
	if (yoffset > 0) {
		MOUSEWHEEL_CHANGE = 1.0f;
	}
	else {
		MOUSEWHEEL_CHANGE = -1.0f;
	}
}

// Resize window function
void OpenGL::framebuffer_size_callback(GLFWwindow* window, int width, int height) {
	glViewport(0, 0, width, height);
}

// Default construtor with default values
OpenGL::OpenGL() {
	isInitialized = false;
	window = nullptr;
	firstCamUpdate = true;
};

// Deconstructor
OpenGL::~OpenGL() {
	glfwTerminate();
}

void OpenGL::charArrayToString(char *charArray, int size) {
	// Log errors
	logOutput.resize(size);
	for (int i = 0; i < size; i++) {
		logOutput.at(i) = charArray[i];
	}
}


void OpenGL::resetTransform() {
	transform = glm::mat4(1.0f);
}

void OpenGL::updateTime() {
	float currentFrame = glfwGetTime();
	deltaTime = currentFrame - lastFrame;
	lastFrame = currentFrame;
}

void OpenGL::setupWindow(int winWidth, int winHeight) {
	//Initialize OpenGL setup using GLFW
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Create a main window
	window = glfwCreateWindow(winWidth, winHeight, "Jason Verrill", NULL, NULL);

	// Error checking
	if (!window) {
		glfwTerminate();
		throw std::runtime_error("Failed to create GLFW window");
	}

	// Set the window as the current context window
	glfwMakeContextCurrent(window);

	// Set function to call on window resize
	glfwSetFramebufferSizeCallback(window, &framebuffer_size_callback);

	// Setup function calls if mouse movement or scroll is detected
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);
}

// Read file data for shaders
std::string OpenGL::readFile(const char* filepath) {
	std::ifstream file;
	std::string fileData;
	std::stringstream fileStream;

	// Open file and ensure it was opened successfully
	file.open(filepath);

	// Error checking
	if (!file.is_open()) {
		throw std::runtime_error("Failed to open the file.\n");
	}

	// Copy file contents to a stream, convert to string, and close the file
	fileStream << file.rdbuf();
	file.close();
	fileData = fileStream.str();

	return fileData;
}

void OpenGL::setupShaders(const char* vsFilepath, const char* fsFilepath) {
	// Error checking variables and data input
	int success = false;
	const int logSize = 512;
	char infoLog[logSize];
	logOutput = "";
	std::string data;

	data = readFile(vsFilepath);
	const char* vertexData = data.c_str();

	// Create vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexData, NULL);
	glCompileShader(vertexShader);

	// Read in the shader and convert to character string
	data = readFile(fsFilepath);
	const char* fragmentData = data.c_str();

	// Create fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentData, NULL);
	glCompileShader(fragmentShader);

	// Error checking for vertex shader
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);

	if (!success) {
		glGetShaderInfoLog(vertexShader, logSize, NULL, infoLog);
		charArrayToString(infoLog, logSize);
		throw std::runtime_error("ERROR::SHADER::VERTEX::COMPILATION_FAILED\n");
	}

	// Error checking for fragment shader
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);

	if (!success) {
		glGetShaderInfoLog(fragmentShader, logSize, NULL, infoLog);
		charArrayToString(infoLog, logSize);
		throw std::runtime_error("ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n");
	}


	// Create shader program
	numShaders++;
	shaderProgram[numShaders-1] = glCreateProgram();

	// Attach shaders
	glAttachShader(shaderProgram[numShaders - 1], vertexShader);
	glAttachShader(shaderProgram[numShaders - 1], fragmentShader);
	glLinkProgram(shaderProgram[numShaders - 1]);

	// Error checking
	glGetProgramiv(shaderProgram[numShaders - 1], GL_LINK_STATUS, &success);

	if (!success) {
		glGetShaderInfoLog(shaderProgram[numShaders - 1], logSize, NULL, infoLog);
		charArrayToString(infoLog, logSize);
		throw std::runtime_error("ERROR::SHADER::SHADER_PROGRAM::COMPILATION_FAILED\n");
	}

	// Delete shaders
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);	
}

void OpenGL::setupCamera() {
	// Camera setup
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Allow better mouse input if supported
	if (glfwRawMouseMotionSupported()) {
		glfwSetInputMode(window, GLFW_RAW_MOUSE_MOTION, GLFW_TRUE);
	}

	// Persepctive and view setup
	int height;
	int width;
	view = glm::mat4(1.0f);
	projection = glm::mat4(1.0f);

	// Get the window dimensions from the main OpenGL window
	glfwGetWindowSize(window, &width, &height);

	// Update camera view
	view = camera.getViewUpdate();

	// Set up perspective with OpenGL
	projection = glm::perspective(glm::radians(45.0f), float(width) / (float)height, 0.1f, 100.0f);
}

// OpenGL setup requirements (includes GLFW and GLAD setup)
int OpenGL::Initialize(int winWidth, int winHeight) {
	try {
		// Initialize values
		numShaders = 0;
		deltaTime = 0.0f;
		lastFrame = 0.0f;
		lastMouseX = 0.0f;
		lastMouseY = 0.0f;
		transform = glm::mat4(1.0f);

		// OpenGL window
		setupWindow(winWidth, winHeight);

		// Initialize GLAD
		// Assists with loading OpenGL function pointers with OS specific addresses
		if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
			throw std::runtime_error("Failed to initialize GLAD");
		}

		// Set the viewport dimensions
		glViewport(0, 0, winWidth, winHeight);

		// Set up camera projection
		setupCamera();

		glm::vec3 objectColor(1.0f, 1.0f, 1.0f);

		// Setup GPU shaders
		
		// Main shader (object.vs, object.fs)
		setupShaders("object.vs", "object.fs");
		viewLocation = glGetUniformLocation(shaderProgram[0], "view");
		projectionLocation = glGetUniformLocation(shaderProgram[0], "projection");
		transformLocation = glGetUniformLocation(shaderProgram[0], "transform");
		camPositionLocation = glGetUniformLocation(shaderProgram[0], "camPosition");
		lightColorLocation = glGetUniformLocation(shaderProgram[0], "lightColor");

		// Light #1
		lightPositionLocation[0] = glGetUniformLocation(shaderProgram[0], "light[0].position");
		lightAmbientLocation[0] = glGetUniformLocation(shaderProgram[0], "light[0].ambient");
		lightDiffuseLocation[0] = glGetUniformLocation(shaderProgram[0], "light[0].diffuse");
		lightSpecularLocation[0] = glGetUniformLocation(shaderProgram[0], "light[0].specular");
		lightLinearLocation[0] = glGetUniformLocation(shaderProgram[0], "light[0].constant");
		lightLinearLocation[0] = glGetUniformLocation(shaderProgram[0], "light[0].linear");
		lightLinearLocation[0] = glGetUniformLocation(shaderProgram[0], "light[0].quadratic");

		// Key Light
		lightPositionLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].position");
		lightDirectionLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].direction");
		lightAmbientLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].ambient");
		lightDiffuseLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].diffuse");
		lightSpecularLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].specular");
		lightLinearLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].constant");
		lightLinearLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].linear");
		lightLinearLocation[1] = glGetUniformLocation(shaderProgram[0], "light[1].quadratic");

		// Fill Light
		lightPositionLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].position");
		lightDirectionLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].direction");
		lightAmbientLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].ambient");
		lightDiffuseLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].diffuse");
		lightSpecularLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].specular");
		lightLinearLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].constant");
		lightLinearLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].linear");
		lightLinearLocation[2] = glGetUniformLocation(shaderProgram[0], "light[2].quadratic");


		glUseProgram(shaderProgram[0]);
		glUniformMatrix4fv(viewLocation, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, glm::value_ptr(projection));

		// Shader just for the light shape (light.vs, light.fs)
		setupShaders("light.vs", "light.fs");
		lightViewLocation = glGetUniformLocation(shaderProgram[1], "view");
		lightProjectionLocation = glGetUniformLocation(shaderProgram[1], "projection");
		lightTransformLocation = glGetUniformLocation(shaderProgram[1], "transform");

		glUseProgram(shaderProgram[1]);
		glUniformMatrix4fv(lightViewLocation, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(lightProjectionLocation, 1, GL_FALSE, glm::value_ptr(projection));


		// Enable depth buffer
		glEnable(GL_DEPTH_TEST);

		// Set default clear buffer color
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);

		// Load model objects
		createManualShapes();

		// Create lights
		createLights();

		// OpenGL has now been intialized
		isInitialized = true;

		return SUCCESS;
	}
	catch (std::runtime_error& exception) {
		// Print error
		std::cout << exception.what() << std::endl;

		if (!logOutput.empty()) {
			std::cout << logOutput << std::endl;
		}

		return 0;
	}
}

// Run the program loop
int OpenGL::Run() {

	// Attempting to run before calling initializiation will fail
	if (!isInitialized) {
		std::cout << "OpenGL hasn't been initialized yet. Please call initialization function first." << std::endl;
		return FAIL;
	}

	// While the window should remain open...
	while (!glfwWindowShouldClose(window)) {
		// Clear the buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Track loop real time
		updateTime();

		// Custom input event processing
		processInput(window);

		// Update camera view
		view = camera.getViewUpdate();


		// Update shader[1]
		glUseProgram(shaderProgram[1]);
		glUniformMatrix4fv(lightViewLocation, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(lightTransformLocation, 1, GL_FALSE, glm::value_ptr(light[0].getPositionMatrix()));


		// Render lights using shader[1]
		glm::vec3 lightChange;
		lightChange.x = sin(glfwGetTime() * 2.0f);
		lightChange.y = sin(glfwGetTime() * 0.7f);
		lightChange.z = sin(glfwGetTime() * 1.3f);

		light[0].render();
		glUniformMatrix4fv(lightTransformLocation, 1, GL_FALSE, glm::value_ptr(light[1].getPositionMatrix()));




		// Update shader[0]
		glUseProgram(shaderProgram[0]);
		glUniformMatrix4fv(viewLocation, 1, GL_FALSE, glm::value_ptr(view));
		glUniform3fv(camPositionLocation, 1, glm::value_ptr(camera.getPosition()));
		glUniform3fv(lightColorLocation, 1, glm::value_ptr(light[0].getColor()));

		
		/*
		// Light #1
		glUniform3fv(lightPositionLocation[0], 1, glm::value_ptr(light[0].getPosition()));
		glUniform3fv(lightAmbientLocation[0], 1, glm::value_ptr(light[0].getAmbient()));
		glUniform3fv(lightDiffuseLocation[0], 1, glm::value_ptr(light[0].getDiffuse()));
		glUniform3fv(lightSpecularLocation[0], 1, glm::value_ptr(light[0].getSpecular()));
		
		
		// Light #2
		glUniform3fv(lightPositionLocation[1], 1, glm::value_ptr(light[1].getPosition()));
		glUniform3fv(lightDirectionLocation[1], 1, glm::value_ptr(light[1].getDirection()));
		glUniform3fv(lightAmbientLocation[1], 1, glm::value_ptr(light[1].getAmbient()));
		glUniform3fv(lightDiffuseLocation[1], 1, glm::value_ptr(light[1].getDiffuse()));
		glUniform3fv(lightSpecularLocation[1], 1, glm::value_ptr(light[1].getSpecular()));
		
		
		// Light #3
		glUniform3fv(lightPositionLocation[2], 1, glm::value_ptr(light[2].getPosition()));
		glUniform3fv(lightDirectionLocation[2], 1, glm::value_ptr(light[2].getDirection()));
		glUniform3fv(lightAmbientLocation[2], 1, glm::value_ptr(light[2].getAmbient()));
		glUniform3fv(lightDiffuseLocation[2], 1, glm::value_ptr(light[2].getDiffuse()));
		glUniform3fv(lightSpecularLocation[2], 1, glm::value_ptr(light[2].getSpecular()));
		*/


		// Update GPU with light data
		for (int i = 0; i < 3; i++) {
			glUniform3fv(lightPositionLocation[i], 1, glm::value_ptr(light[i].getPosition()));
			
			glUniform3fv(lightAmbientLocation[i], 1, glm::value_ptr(light[i].getAmbient()));
			glUniform3fv(lightDiffuseLocation[i], 1, glm::value_ptr(light[i].getDiffuse()));
			glUniform3fv(lightSpecularLocation[i], 1, glm::value_ptr(light[i].getSpecular()));

			glUniform1f(lightDirectionLocation[i], light[i].getConstant());
			glUniform1f(lightDirectionLocation[i], light[i].getLinear());
			glUniform1f(lightDirectionLocation[i], light[i].getQuadratic());
		}

		glUniform3fv(lightDirectionLocation[1], 1, glm::value_ptr(light[1].getDirection()));



		// Draw objects using shader[0]
		plane[0].draw();
		//cube[0].draw();
		//pyramid[0].draw();
		
		pencilTip.draw();
		pencilBody.draw();
		pencilFerrule.draw();
		pencilEraser.draw();

		deskOrganizerLip.draw();
		deskOrganizerInsert.draw();

		chargerBank.draw();

		cupLip.draw();
		cupBody.draw();

		// Swap to next buffer
		glfwSwapBuffers(window);

		// Handle incoming events
		glfwPollEvents();
	}
}

// Custom handling of specific events
void OpenGL::processInput(GLFWwindow* window) {
	float mouseXChange;
	float mouseYChange;
	int width;
	int height;

	// Get window dimensions
	glfwGetWindowSize(window, &width, &height);

	// Sync controls with real time
	camera.updateTime(deltaTime);


	// Update camera rotation
	if (firstCamUpdate) {
		double mouseXPos;
		double mouseYPos;

		glfwGetCursorPos(window, &mouseXPos, &mouseYPos);
		MOUSE_X_POSITION = mouseXPos;
		MOUSE_Y_POSITION = mouseYPos;
		lastMouseX = mouseXPos;
		lastMouseY = mouseYPos;
		firstCamUpdate = false;
	}

	// Calculate amount of mouse change and update camera
	mouseXChange = MOUSE_X_POSITION - lastMouseX;
	mouseYChange = MOUSE_Y_POSITION - lastMouseY;
	lastMouseX = MOUSE_X_POSITION;
	lastMouseY = MOUSE_Y_POSITION;

	camera.updateRotation(mouseXChange, mouseYChange);

	if (MOUSEWHEEL_CHANGE > 0.0f) {
		camera.increaseSpeed();
	}
	else if (MOUSEWHEEL_CHANGE < 0.0f) {
		camera.decreaseSpeed();
	}

	MOUSEWHEEL_CHANGE = 0.0f;

	// If escape key is pressed, close the window
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, true);
	}

	if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS) {
		// Set to fill mode
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}

	if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS) {
		// Set to wireframe mode
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}

	// Toggle perspective and orthogonal mode
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {

		if (projectionType) {
			projection = glm::perspective(glm::radians(45.0f), (float)width / (float)height, 0.1f, 100.0f);
		}
		else {
			projection = glm::ortho(0.0f, 5.0f, 0.0f, 5.0f, 0.1f, 100.0f);
		}

		projectionType = !projectionType;
		glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, glm::value_ptr(projection));
	}

	// Move camera up
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
		camera.moveUp();
	}

	// Move camera down
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
		camera.moveDown();
	}

	// Move camera forward
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
		camera.moveForward();
	}

	// Move camera backward
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
		camera.moveBackward();
	}

	// Strafe camera left
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		camera.moveLeft();
	}

	// Strafe camera right
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
		camera.moveRight();
	}

	float maxLightMovement = 20.0f;
	float lightSpeed = 0.1f;

	// Move light right
	if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
		if (light[0].getPosition().x < maxLightMovement) {
			light[0].setPosition(lightSpeed, 0.0f, 0.0f);
		}
	}

	// Move light left
	if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
		if (light[0].getPosition().x > -maxLightMovement) {
			light[0].setPosition(-lightSpeed, 0.0f, 0.0f);
		}
	}

	// Move light forward
	if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {
		if (light[0].getPosition().z > -maxLightMovement) {
			light[0].setPosition(0.0f, 0.0f, -lightSpeed);
		}
	}

	// Move light backward
	if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {
		if (light[0].getPosition().z < maxLightMovement) {
			light[0].setPosition(0.0f, 0.0f, lightSpeed);
		}
	}

	// Toggle light
	if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
		light[0].toggle();
	}
}

void OpenGL::createManualShapes() {
	// Create triangle
	std::vector<float> triangleVertices = {
		0.0f,  0.5f, 0.0f,		1.0f, 0.0f, 0.0f,		// top
		0.5f, -0.5f, 0.0f,		0.0f, 1.0f, 0.0f,		// bottom right
		-0.5f, -0.5f, 0.0f,		0.0f, 0.0f, 1.0f,		// bottom left
	};

	std::vector<unsigned int> triangleIndices = {
		0, 1, 2,
	};

	// Create triangle buffer and set starting transform
	/*
	triangle[0].CreateShape(triangleVertices, triangleIndices, transformLocation, modelSpace);
	triangle[0].setScale(0.25f, 0.25f, 0.25f);
	triangle[0].setPosition(-0.5f, 0.0f, 0.0f);

	triangle[1].CreateShape(triangleVertices, triangleIndices, transformLocation, modelSpace);
	triangle[1].setScale(0.25f, 0.25f, 0.25f);
	triangle[1].setPosition(0.3f, -0.3f, 0.0f);
	*/

	// Create rectangle
	std::vector<float> rectangleVertices = {
		0.5f,  0.5f, 0.0f,		1.0f, 0.0f, 0.0f,		// top right
		0.5f, -0.5f, 0.0f,		0.0f, 1.0f, 0.0f,		// bottom right
		-0.5f, -0.5f, 0.0f,		0.0f, 0.0f, 1.0f,		// bottom left
		-0.5f,  0.5f, 0.0f,		1.0f, 1.0f, 0.0f,		// top left 
	};

	std::vector<unsigned int> rectangleIndices = {
		0,1,2,
		0,2,3
	};

	// Create rectangle and set starting transform
	//rectangle[0].CreateShape(rectangleVertices, rectangleIndices, transformLocation, modelSpace);
	//rectangle[0].setPosition(0.0f, -0.5f, 0.0f);
	//rectangle[0].setRotation(90.0f, 1.0f, 0.0f, 0.0f);
	//rectangle[0].setScale(20.0f, 20.0f, 20.0f);


	// Pyramid
	std::vector<float> pyramidVertices = {
		// Base
		-0.5f, -0.5f, -0.5f,		0.0f, -1.0f, 0.0f,	0.0f, 0.0f,
		0.5f, -0.5f, -0.5f,			0.0f, -1.0f, 0.0f,	1.0f, 0.0f,
		0.5f, -0.5f, 0.5f,			0.0f, -1.0f, 0.0f, 	1.0f, 1.0f,
		-0.5f, -0.5f, 0.5f,			0.0f, -1.0f, 0.0f, 	0.0f, 1.0f,

		// Tip
		0.0f, 0.5f, 0.0f,			0.0f, 1.0f, 1.0f,	0.5f, 1.0f,

		// Back
		-0.5f, -0.5f, -0.5f,			0.0f, 0.0f, 1.0f, 	0.0f, 0.0f,
		0.5f, -0.5f, -0.5f,			0.0f, 0.0f, 1.0f, 	1.0f, 0.0f,

		// Right
		0.5f, -0.5f, 0.5f,			1.0f, 0.0f, 0.0f,	0.0f, 0.0f,
		0.5f, -0.5f, -0.5f,			1.0f, 0.0f, 0.0f, 	1.0f, 0.0f,

		// Left
		-0.5f, -0.5f, -0.5f,		-1.0f, 0.0f, 0.0f,	0.0f, 0.0f,
		-0.5f, -0.5f, 0.5f,			-1.0f, 0.0f, 0.0f, 	1.0f, 0.0f,

		// Front
		-0.5f, -0.5f, 0.5f,			0.0f, 0.0f, -1.0f, 	0.0f, 0.0f,
		0.5f, -0.5f, 0.5f,			0.0f, 0.0f, -1.0f, 	1.0f, 0.0f,
	};

	std::vector<unsigned int> pyramidIndices = {
		// Base
		0,1,2,
		0,2,3,

		5,6,4,		// back
		11,12,4,		// front
		7,8,4,		// right
		9,10,4,		// left

	};

	pyramid[0].createShape(pyramidVertices, pyramidIndices, transformLocation, transform);
	pyramid[0].addMaterial(shaderProgram[0], glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(0.2f, 0.2f, 0.2f), 8);
	pyramid[0].addTexture("brick.jpg", 0);
	pyramid[0].setPosition(0.0f, 2.0f, 0.0f);
	pyramid[0].setScale(5.0f, 5.0f, 5.0f);

	std::vector<float> planeVertices = {
		-1.0f, 0.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.0f, 1.0f,		// far left corner
		1.0f, 0.0f, -1.0f,		0.0f, 1.0f, 0.0f,		1.0f, 1.0f,		// far right corner
		1.0f, 0.0f, 1.0f,		0.0f, 1.0f, 0.0f,		1.0f, 0.0f,		// near right corner
		-1.0f, 0.0f, 1.0f,		0.0f, 1.0f, 0.0f,		0.0f, 0.0f,		// near left corner
	};

	std::vector<unsigned int> planeIndices = {
		0,1,2,
		0,2,3,
	};

	plane[0].createShape(planeVertices, planeIndices, transformLocation, transform);
	plane[0].addMaterial(shaderProgram[0], glm::vec3(0.1f, 0.1f, 0.1f), glm::vec3(0.0f, 1.0f, 1.0f), glm::vec3(0.2f, 0.2f, 0.2f), 8);
	plane[0].addTexture("desk.png", 0);
	plane[0].setScale(25.0f, 25.0f, 25.0f);

	std::vector<float> pencilVertices = {
		// Tip
		-10.0f, 0.0f, 0.0f,		1.0f, 0.0f, 0.0f,	0.5f, 1.0f,		// tip
		-8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim top
		-8.0f, 0.5f, 1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 0.0f,		// hexagon rim far high edge
		-8.0f, -0.5f, 1.0f,		1.0f, 1.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim far low edge
		-8.0f, -1.0f, 0.0f,		1.0f, 0.0f, 1.0f,	0.0f, 0.0f,		// hexagon rim bottom edge
		-8.0f, -0.5f, -1.0f,	0.0f, 1.0f, 1.0f,	0.0f, 0.0f,		// hexagon rim near low edge
		-8.0f, 0.5f, -1.0f,		1.0f, 1.0f, 1.0f,	0.0f, 0.0f,		// hexagon rim bottom


		// Body - starts at index 7
		8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,   0.0f, 1.0f,		// hexagon rim top
		8.0f, 0.5f, 1.0f,		0.0f, 0.0f, 1.0f,   1.0f, 0.0f,		// hexagon rim far high edge
		8.0f, -0.5f, 1.0f,		1.0f, 1.0f, 0.0f,	0.0f, 1.0f,		// hexagon rim far low edge
		8.0f, -1.0f, 0.0f,		1.0f, 0.0f, 1.0f,	1.0f, 1.0f,		// hexagon rim bottom edge
		8.0f, -0.5f, -1.0f,		0.0f, 1.0f, 1.0f,	1.0f, 0.0f,		// hexagon rim near low edge
		8.0f, 0.5f, -1.0f,		1.0f, 1.0f, 1.0f,	0.0f, 1.0f,		// hexagon rim bottom



		// Clip - starts at index 13
		// Clip Holder
		1.0f, 0.4f, 1.8f,		0.5f, 0.5f, 0.5f,	0.0f, 1.0f,		// Top left corner 13
		6.0f, 0.4f, 1.8f,		0.5f, 0.5f, 0.5f,	1.0f, 1.0f,		// Top right corner (shared with clip connection) 14
		6.0f, -0.4f, 1.8f,		0.5f, 0.5f, 0.5f,	1.0f, 0.0f,		// Bottom right corner (shared with clip connection) 15
		1.0f, -0.4f, 1.8f,		0.5f, 0.5f, 0.5f,	0.0f, 0.0f,     // Bottom left corner  16
		// Clip connection to body
		6.0f, 0.4f, 1.0f,		0.0f, 1.0f, 0.0f,   1.0f, 0.0f,		// Top far corner 17
		6.0f, -0.4f, 1.0f,		0.0f, 1.0f, 0.0f,   0.0f, 0.0f,		// Bottom far corner 18



		// Eraser - starts at index 19
		// Base at the top of the body
		8.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,     // hexagon rim top
		8.5f, 0.5f, 1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 0.0f,     // hexagon rim far high edge
		8.5f, -0.5f, 1.0f,		1.0f, 1.0f, 0.0f,	0.0f, 0.0f,     // hexagon rim far low edge
		8.5f, -1.0f, 0.0f,		1.0f, 0.0f, 1.0f,	0.0f, 0.0f,     // hexagon rim bottom edge
		8.5f, -0.5f, -1.0f,		0.0f, 1.0f, 1.0f,	0.0f, 0.0f,     // hexagon rim near low edge
		8.5f, 0.5f, -1.0f,		1.0f, 1.0f, 1.0f,	0.0f, 0.0f,     // hexagon rim bottom
		// Top of the eraser
		9.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,     // hexagon rim top 25
		9.5f, 0.5f, 1.0f,		0.0f, 0.0f, 1.0f,	1.0f, 0.0f,     // hexagon rim far high edge
		9.5f, -0.5f, 1.0f,		1.0f, 1.0f, 0.0f,	0.0f, 1.0f,     // hexagon rim far low edge
		9.5f, -1.0f, 0.0f,		1.0f, 0.0f, 1.0f,	1.0f, 1.0f,     // hexagon rim bottom edge
		9.5f, -0.5f, -1.0f,		0.0f, 1.0f, 1.0f,	1.0f, 0.0f,     // hexagon rim near low edge
		9.5f, 0.5f, -1.0f,		1.0f, 1.0f, 1.0f,	0.0f, 1.0f,		// hexagon rim bottom

		// Body top lid (forgot to do it earlier) - starts at 31
		8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim top
		8.0f, 0.5f, 1.0f,		0.0f, 0.0f, 1.0f,	1.0f, 0.0f,     // hexagon rim far high edge
		8.0f, -0.5f, 1.0f,		1.0f, 1.0f, 0.0f,	0.0f, 1.0f,     // hexagon rim far low edge
		8.0f, -1.0f, 0.0f,		1.0f, 0.0f, 1.0f,	1.0f, 1.0f,     // hexagon rim bottom edge
		8.0f, -0.5f, -1.0f,		0.0f, 1.0f, 1.0f,	1.0f, 0.0f,     // hexagon rim near low edge
		8.0f, 0.5f, -1.0f,		1.0f, 1.0f, 1.0f,	0.0f, 1.0f,     // hexagon rim bottom
	};



	// Index data to share position data
	std::vector<unsigned int> pencilIndices = {
		//Tip
		0,1,2,
		0,2,3,
		0,3,4,
		0,4,5,
		0,5,6,
		0,6,1,

		// Body
		1,2,7,
		7,8,2,
		2,3,8,
		8,9,3,
		3,4,9,
		9,10,4,
		4,5,10,
		10,11,5,
		5,6,11,
		11,12,6,
		6,7,12,
		6,7,1,

		// Clip
		// Holder
		13,14,15,
		13,15,16,
		// Connection
		14,17,18,
		14,18,15,

		// Eraser
		// Base
		19,20,21,
		19,21,22,
		19,22,23,
		19,23,24,
		// Top
		25,26,27,
		25,27,28,
		25,28,29,
		25,29,30,
		// Sides
		19,25,26,
		19,20,26,
		20,26,27,
		20,27,21,
		21,27,28,
		21,28,22,
		22,28,29,
		22,29,23,
		23,29,30,
		23,30,24,
		24,30,25,
		24,25,19,

		31,32,33,
		31,33,34,
		31,34,35,
		31,35,36,
	};

	pencil[0].createShape(pencilVertices, pencilIndices, transformLocation, transform);
	pencil[0].addTexture("grayplastic.jpg", 0);
	pencil[0].addTexture("pencilwood.jpg", 18);
	pencil[0].setPosition(0.0f, 1.0f, 0.0f);
	pencil[0].setScale(0.5f, 0.5f, 0.5f);
	pencil[0].setRotation(45.0f, 0.0f, 1.0f, 0.0f);
	
	std::vector<float> testObjectV = {
		// Face
		-1.0f, 1.0f, 0.0f,		0.0f, 0.0f, 0.0f,		0.0f, 1.0f,		// top left
		1.0f, 1.0f, 0.0f,		0.0f, 0.0f, 0.0f,		1.0f, 1.0f,		// top right
		1.0f, -1.0f, 0.0f,		0.0f, 0.0f, 0.0f,		1.0f, 0.0f,		// bottom right
		-1.0f, -1.0f, 0.0f,		0.0f, 0.0f, 0.0f,		0.0f, 0.0f,		// bottom left
	};



	std::vector<unsigned int> testObjectI = {
		0,1,2,
		0,2,3,
	};

	//testObject.CreateShape(testObjectV, testObjectI, transformLocation, modelSpace);
	//testObject.addTexture("brick.jpg", 0);
	//testObject.addTexture("grayplastic.jpg", 3);

	std::vector<float> newPencilVertices = {
		// Tip
		// offset 0
		-10.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.5f,		// tip
		-8.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.5f, 1.0f,		// hexagon rim top
		-8.0f, 0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.75f,		// hexagon rim near high edge
		-8.0f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.25f,		// hexagon rim near low edge
		-8.0f, -1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.5f, 0.0f,		// hexagon rim bottom
		-8.0f, -0.5f, -1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.25f,		// hexagon rim far low edge
		-8.0f, 0.5f, -1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.75f,		// hexagon rim far high edge

		/*
		// Tip
		// offset 7
		-10.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.5f,		// tip
		-8.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.5f, 1.0f,		// hexagon rim top
		-8.0f, 0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.75f,		// hexagon rim near high edge
		-8.0f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.25f,		// hexagon rim near low edge
		-8.0f, -1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.5f, 0.0f,		// hexagon rim bottom
		-8.0f, -0.5f, -1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.25f,		// hexagon rim far low edge
		-8.0f, 0.5f, -1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.75f,		// hexagon rim far high edge
		*/

		// Body
		// offset 18
		// Body - starts at index 7
		8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,   0.0f, 1.0f,		// hexagon rim top
		8.0f, 0.5f, 1.0f,		0.0f, 0.0f, 1.0f,   0.0f, 0.75f,		// hexagon rim near high edge
		8.0f, -0.5f, 1.0f,		1.0f, 1.0f, 0.0f,	0.0f, 0.25f,		// hexagon rim near low edge
		8.0f, -1.0f, 0.0f,		1.0f, 0.0f, 1.0f,	0.0f, 0.0f,		// hexagon rim bottom edge
		8.0f, -0.5f, -1.0f,		0.0f, 1.0f, 1.0f,	1.0f, 0.25f,		// hexagon rim far low edge
		8.0f, 0.5f, -1.0f,		1.0f, 1.0f, 1.0f,	0.0f, 0.75f,		// hexagon rim far high edge

	};

	std::vector<unsigned int> newPencilIndices = {
		0,1,2,
		0,2,3,
		0,3,4,
		0,4,5,
		0,5,6,
		0,6,1,

		1,7,8,
		1,8,2,
		2,8,9,
		2,9,3,
		3,9,10,
		3,10,4,
		4,10,11,
		4,11,5,
		5,11,12,
		5,12,6,
		6,12,7,
		6,7,1,
	};

	newPencil[0].createShape(newPencilVertices, newPencilIndices, transformLocation, transform);
	newPencil[0].addTexture("pencilwood.jpg", 0);
	newPencil[0].addTexture("blueplastic.jpg", 18);


	std::vector<float> cubeVertices = {
		// Front face
		-1.0f, 1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 1.0f,		// top left
		1.0f, 1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	1.0f, 1.0f,		// top right
		1.0f, -1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	1.0f, 0.0f,		// bottom right
		-1.0f, -1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 0.0f,		// bottom left

		// Back face
		-1.0f, 1.0f, -1.0f,		0.0f, 0.0f, -1.0f,	1.0f, 1.0f,		// top left
		1.0f, 1.0f, -1.0f,		0.0f, 0.0f, -1.0f,	0.0f, 1.0f,		// top right
		1.0f, -1.0f, -1.0f,		0.0f, 0.0f, -1.0f,	0.0f, 0.0f,		// bottom right
		-1.0f, -1.0f, -1.0f,	0.0f, 0.0f, -1.0f,	1.0f, 0.0f,		// bottom left

		// Right face
		1.0f, 1.0f, 1.0f,		1.0f, 0.0f,	0.0f,	0.0f, 1.0f,		// near top
		1.0f, 1.0f, -1.0f,		1.0f, 0.0f,	0.0f,	1.0f, 1.0f,		// far top
		1.0f, -1.0f, -1.0f,		1.0f, 0.0f,	0.0f,	1.0f, 0.0f,		// far bottom
		1.0f, -1.0f, 1.0f,		1.0f, 0.0f,	0.0f,	0.0f, 0.0f,		// near bottom

		// Left face
		-1.0f, 1.0f, 1.0f,		-1.0f, 0.0f, 0.0f,	0.0f, 1.0f,		// near top
		-1.0f, 1.0f, -1.0f,		-1.0f, 0.0f, 0.0f,	1.0f, 1.0f,		// far top
		-1.0f, -1.0f, -1.0f,	-1.0f, 0.0f, 0.0f,	1.0f, 0.0f,		// far bottom
		-1.0f, -1.0f, 1.0f,		-1.0f, 0.0f, 0.0f,	0.0f, 0.0f,		// near bottom

		// Top face
		-1.0f, 1.0f, 1.0f,		0.0f, 1.0f,	0.0f,	0.0f, 1.0f,		// far left
		1.0f, 1.0f, 1.0f,		0.0f, 1.0f,	0.0f,	1.0f, 1.0f,		// far right
		1.0f, 1.0f, -1.0f,		0.0f, 1.0f,	0.0f,	1.0f, 0.0f,		// near right
		-1.0f, 1.0f, -1.0f,		0.0f, 1.0f,	0.0f,	0.0f, 0.0f,		// near left

		// Bottom face
		-1.0f, -1.0f, 1.0f,		0.0f, -1.0f, 0.0f,	0.0f, 1.0f,		// far left
		1.0f, -1.0f, 1.0f,		0.0f, -1.0f, 0.0f,	1.0f, 1.0f,		// far right
		1.0f, -1.0f, -1.0f,		0.0f, -1.0f, 0.0f,	1.0f, 0.0f,		// near right
		-1.0f, -1.0f, -1.0f,	0.0f, -1.0f, 0.0f,	0.0f, 0.0f,		// near left
	};

	std::vector<unsigned int> cubeIndices = {
		0,1,2,
		0,2,3,
		
		4,5,6,
		4,6,7,
		
		8,9,10,
		8,10,11,

		12,13,14,
		12,14,15,

		16,17,18,
		16,18,19,

		20,21,22,
		20,22,23,
	};

	cube[0].createShape(cubeVertices, cubeIndices, transformLocation, transform);
	cube[0].addMaterial(shaderProgram[0], glm::vec3(0.0f, 1.0f, 1.0f), glm::vec3(0.0f, 1.0f, 1.0f), glm::vec3(0.5f, 0.5f, 0.5f), 256);
	//cube[0].setScale(3.0f, 3.0f, 3.0f);
	cube[0].addTexture("brick.jpg");
	cube[0].setPosition(2.0f, 2.0f, 0.0f);

	cube[1].createShape(cubeVertices, cubeIndices, transformLocation, transform);
	cube[1].setPosition(2.0f, 2.0f, 0.0f);


	// Pencil

	std::vector<float> pencilTipV = {
		// Tip
		-10.0f, 0.0f, 0.0f,		-1.0f, 0.0f, 0.0f,	0.5f, 0.5f,		// tip
		-8.0f, 1.0f, 0.0f,		-1.0f, 0.0f, 0.0f,	0.5f, 1.0f,		// hexagon rim top
		-8.0f, 0.5f, -1.0f,		-1.0f, 0.0f, 0.0f,	0.0f, 0.75,		// hexagon rim far high edge
		-8.0f, -0.5f, -1.0f,	-1.0f, 0.0f, 0.0f,	0.0f, 0.25,		// hexagon rim far low edge
		-8.0f, -1.0f, 0.0f,		-1.0f, 0.0f, 0.0f,	0.5f, 0.0f,		// hexagon rim bottom edge
		-8.0f, -0.5f, 1.0f,		-1.0f, 0.0f, 0.0f,	1.0f, 0.25f,	// hexagon rim near low edge
		-8.0f, 0.5f, 1.0f,		-1.0f, 0.0f, 0.0f,	1.0f, 0.75f,	// hexagon rim bottom
	};

	std::vector<unsigned int> pencilTipI = {
		0,1,2,
		0,2,3,
		0,3,4,
		0,4,5,
		0,5,6,
		0,6,1,
	};




	std::vector<float> pencilBodyV = {
		// Left vertices (toward tip)
		-8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 1.0f,	0.0f, 1.0f,		// hexagon rim top
		-8.0f, 0.5f, -1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 0.17,		// hexagon rim far high edge
		-8.0f, -0.5f, -1.0f,	0.0f, -1.0f, 1.0f,	0.0f, 0.33,		// hexagon rim far low edge
		-8.0f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,	0.5f, 0.5f,		// hexagon rim bottom edge
		-8.0f, -0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	0.0f, 0.67f,	// hexagon rim near low edge
		-8.0f, 0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	0.0f, 0.83f,	// hexagon rim bottom
		-8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim top (bottom texture)

		// Right vertices (toward eraser)
		8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 1.0f,   1.0f, 1.0f,		// hexagon rim top
		8.0f, 0.5f, -1.0f,		0.0f, 0.0f, 1.0f,   1.0f, 0.17f,	// hexagon rim far high edge
		8.0f, -0.5f, -1.0f,		0.0f, -1.0f, 1.0f,	1.0f, 0.33f,	// hexagon rim far low edge
		8.0f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,	1.0f, 0.5f,		// hexagon rim bottom edge
		8.0f, -0.5f, 1.0f,		0.0f, -1.0f, 1.0f,	1.0f, 0.67f,	// hexagon rim near low edge
		8.0f, 0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	1.0f, 0.83f,	// hexagon rim bottom
		8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,   1.0f, 0.0f,		// hexagon rim top
	};

	std::vector<unsigned int> pencilBodyI = {
		0,1,7,
		7,8,1,

		1,2,8,
		8,9,2,

		2,3,9,
		9,10,3,

		3,4,10,
		10,11,4,

		4,5,11,
		11,12,5,

		5,6,12,
		12,13,6,
	};

	std::vector<float> pencilFerruleV = {
		// Left vertices
		8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 1.0f,	0.0f, 1.0f,		// hexagon rim top
		8.0f, 0.5f, -1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 0.17,		// hexagon rim far high edge
		8.0f, -0.5f, -1.0f,	0.0f, -1.0f, 1.0f,	0.0f, 0.33,		// hexagon rim far low edge
		8.0f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,	0.5f, 0.5f,		// hexagon rim bottom edge
		8.0f, -0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	0.0f, 0.67f,	// hexagon rim near low edge
		8.0f, 0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	0.0f, 0.83f,	// hexagon rim bottom
		8.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim top (bottom texture)

		// Right vertices
		9.7f, 1.0f, 0.0f,		0.0f, 1.0f, 1.0f,   1.0f, 1.0f,		// hexagon rim top
		9.7f, 0.5f, -1.0f,		0.0f, 0.0f, 1.0f,   1.0f, 0.17f,	// hexagon rim far high edge
		9.7f, -0.5f, -1.0f,		0.0f, -1.0f, 1.0f,	1.0f, 0.33f,	// hexagon rim far low edge
		9.7f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,	1.0f, 0.5f,		// hexagon rim bottom edge
		9.7f, -0.5f, 1.0f,		0.0f, -1.0f, 1.0f,	1.0f, 0.67f,	// hexagon rim near low edge
		9.7f, 0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	1.0f, 0.83f,	// hexagon rim bottom
		9.7f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,   1.0f, 0.0f,		// hexagon rim top
	};

	std::vector<unsigned int> pencilFerruleI = {
		0,1,7,
		7,8,1,

		1,2,8,
		8,9,2,

		2,3,9,
		9,10,3,

		3,4,10,
		10,11,4,

		4,5,11,
		11,12,5,

		5,6,12,
		12,13,6,
	};

	std::vector<float> pencilEraserV = {
		// Left vertices
		9.7f, 1.0f, 0.0f,		0.0f, 1.0f, 1.0f,	0.0f, 1.0f,		// hexagon rim top
		9.7f, 0.5f, -1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 0.17,		// hexagon rim far high edge
		9.7f, -0.5f, -1.0f,		0.0f, -1.0f, 1.0f,	0.0f, 0.33,			// hexagon rim far low edge
		9.7f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,	0.5f, 0.5f,		// hexagon rim bottom edge
		9.7f, -0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	0.0f, 0.67f,	// hexagon rim near low edge
		9.7f, 0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	0.0f, 0.83f,	// hexagon rim bottom
		9.7f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim top (bottom texture)

		// Right vertices 
		11.0f, 1.0f, 0.0f,		0.0f, 1.0f, 1.0f,   1.0f, 1.0f,		// hexagon rim top
		11.0f, 0.5f, -1.0f,		0.0f, 0.0f, 1.0f,   1.0f, 0.17f,	// hexagon rim far high edge
		11.0f, -0.5f, -1.0f,	0.0f, -1.0f, 1.0f,	1.0f, 0.33f,	// hexagon rim far low edge
		11.0f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,	1.0f, 0.5f,		// hexagon rim bottom edge
		11.0f, -0.5f, 1.0f,		0.0f, -1.0f, 1.0f,	1.0f, 0.67f,	// hexagon rim near low edge
		11.0f, 0.5f, 1.0f,		0.0f, -1.0f, -1.0f,	1.0f, 0.83f,	// hexagon rim bottom
		11.0f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,   1.0f, 0.0f,		// hexagon rim top

		// Top
		11.0f, 1.0f, 0.0f,		1.0f, 0.0f, 0.0f,  0.0f, 0.0f,		// hexagon rim top
		11.0f, 0.5f, -1.0f,		1.0f, 0.0f, 0.0f,  0.0f, 0.0f,		// hexagon rim far high edge
		11.0f, -0.5f, -1.0f,	1.0f, 0.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim far low edge
		11.0f, -1.0f, 0.0f,		1.0f, 0.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim bottom edge
		11.0f, -0.5f, 1.0f,		1.0f, 0.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim near low edge
		11.0f, 0.5f, 1.0f,		1.0f, 0.0f, 0.0f,	0.0f, 0.0f,		// hexagon rim bottom
	};

	std::vector<unsigned int> pencilEraserI = {
		// Hexagon faces
		0,1,7,
		7,8,1,

		1,2,8,
		8,9,2,

		2,3,9,
		9,10,3,

		3,4,10,
		10,11,4,

		4,5,11,
		11,12,5,

		5,6,12,
		12,13,6,

		// Top
		14,15,16,
		14,16,17,
		14,17,18,
		14,18,19,
		14,19,20,
		14,20,15,
	};

	pencilEraser.createShape(pencilEraserV, pencilEraserI, transformLocation, transform);
	pencilEraser.setPosition(4.8f, 1.0f, -5.0f);
	pencilEraser.addTexture("eraser.jpg");
	pencilEraser.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(0.1f, 0.1f, 0.1f), 8);
	pencilEraser.setScale(1.0f, 0.95f, 0.95f);
	pencilEraser.setRotation(30.0, 0.0f, 1.0f, 0.0f);

	pencilFerrule.createShape(pencilFerruleV, pencilFerruleI, transformLocation, transform);
	pencilFerrule.setPosition(5.0f, 1.0f, -5.0f);
	pencilFerrule.addTexture("metalbase.jpg");
	pencilFerrule.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), 256);
	pencilFerrule.setRotation(30.0, 0.0f, 1.0f, 0.0f);

	pencilBody.createShape(pencilBodyV, pencilBodyI, transformLocation, transform);
	pencilBody.setPosition(5.0f, 1.0f, -5.0f);
	pencilBody.addTexture("blueplastic.jpg");
	pencilBody.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), 8);
	pencilBody.setRotation(30.0, 0.0f, 1.0f, 0.0f);

	pencilTip.createShape(pencilTipV, pencilTipI, transformLocation, transform);
	pencilTip.setPosition(5.0f, 1.0f, -5.0f);
	pencilTip.addTexture("pencilwood.jpg");
	pencilTip.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), 8);
	pencilTip.setRotation(30.0, 0.0f, 1.0f, 0.0f);


	std::vector<float> deskOrganizerLipV = {
		// Outer Octogon - index 0
		-0.7f, 1.3f, 0.0f,		0.0f, 0.0f, 1.0f,		0.25f, 1.0f,
		0.7f, 1.3f, 0.0f,		0.0f, 0.0f, 1.0f,		0.75f, 1.0f,
		1.2f, 0.8f, 0.0f,		0.0f, 0.0f, 1.0f,		1.0f, 0.75f,
		1.2f, -0.8f, 0.0f,		0.0f, 0.0f, 1.0f,		1.0f, 0.25f,
		0.7f, -1.3f, 0.0f,		0.0f, 0.0f, 1.0f,		0.75f, 0.0f,
		-0.7f, -1.3f, 0.0f,		0.0f, 0.0f, 1.0f,		0.25f, 0.0f,
		-1.2f, -0.8f, 0.0f,		0.0f, 0.0f, 1.0f,		0.0f, 0.25f,
		-1.2f, 0.8f, 0.0f,		0.0f, 0.0f, 1.0f,		0.0f, 0.75f,

		// Inner Octogon - index 8
		-0.5f, 1.0f, 0.0f,		0.0f, 0.0f, 1.0f,		0.25f, 1.0f,
		0.5f, 1.0f, 0.0f,		0.0f, 0.0f, 1.0f,		0.75f, 1.0f,
		1.0f, 0.5f, 0.0f,		0.0f, 0.0f, 1.0f,		1.0f, 0.75f,
		1.0f, -0.5f, 0.0f,		0.0f, 0.0f, 1.0f,		1.0f, 0.25f,
		0.5f, -1.0f, 0.0f,		0.0f, 0.0f, 1.0f,		0.75f, 0.0f,
		-0.5f, -1.0f, 0.0f,		0.0f, 0.0f, 1.0f,		0.25f, 0.0f,
		-1.0f, -0.5f, 0.0f,		0.0f, 0.0f, 1.0f,		0.0f, 0.25f,
		-1.0f, 0.5f, 0.0f,		0.0f, 0.0f, 1.0f,		0.0f, 0.75f,
	};

	std::vector<unsigned int> deskOrganizerLipI = {
		// Top edge
		0,1,8,
		8,9,1,

		// Upper Right
		1,2,9,
		9,10,2,

		// Right
		2,3,10,
		10,11,3,

		// Lower right
		3,4,11,
		11,12,4,

		// Bottom
		4,5,12,
		12,13,5,

		// Lower left
		5,6,13,
		13,14,6,

		// Left
		6,7,14,
		14,15,7,

		// Lower left
		7,0,15,
		15,8,0,
	};

	std::vector<float> deskOrganizerInsertV = {
		// Front - index 8
		-0.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,		0.25f, 1.0f,
		0.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,		0.75f, 1.0f,
		1.0f, 0.5f, 0.0f,		0.0f, 1.0f, 0.0f,		1.0f, 0.75f,
		1.0f, -0.5f, 0.0f,		1.0f, 0.0f, 0.0f,		1.0f, 0.25f,
		0.5f, -1.0f, 0.0f,		1.0f, 0.0f, 0.0f,		0.75f, 0.0f,
		-0.5f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,		0.25f, 0.0f,
		-1.0f, -0.5f, 0.0f,		0.0f, -1.0f, 0.0f,		0.0f, 0.25f,
		-1.0f, 0.5f, 0.0f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.75f,

		// Back - index 8
		-0.5f, 1.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.25f, 1.0f,
		0.5f, 1.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.75f, 1.0f,
		1.0f, 0.5f, -1.0f,		0.0f, 1.0f, 0.0f,		1.0f, 0.75f,
		1.0f, -0.5f, -1.0f,		1.0f, 0.0f, 0.0f,		1.0f, 0.25f,
		0.5f, -1.0f, -1.0f,		1.0f, 0.0f, 0.0f,		0.75f, 0.0f,
		-0.5f, -1.0f, -1.0f,	0.0f, -1.0f, 0.0f,		0.25f, 0.0f,
		-1.0f, -0.5f, -1.0f,	0.0f, -1.0f, 0.0f,		0.0f, 0.25f,
		-1.0f, 0.5f, -1.0f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.75f,


	};

	std::vector<unsigned int> deskOrganizerInsertI = {
		// Top edge
		0,1,8,
		8,9,1,

		// Upper Right
		1,2,9,
		9,10,2,

		// Right
		2,3,10,
		10,11,3,

		// Lower right
		3,4,11,
		11,12,4,

		// Bottom
		4,5,12,
		12,13,5,

		// Lower left
		5,6,13,
		13,14,6,

		// Left
		6,7,14,
		14,15,7,

		// Lower left
		7,0,15,
		15,8,0,
	};

	deskOrganizerLip.createShape(deskOrganizerLipV, deskOrganizerLipI, transformLocation, transform);
	deskOrganizerLip.setPosition(-12.0f, 2.0f, -12.0f);
	deskOrganizerLip.setScale(2.0f, 2.0f, 2.0f);
	deskOrganizerLip.setRotation(-90.0f, 1.0f, 0.0f, 0.0f);
	deskOrganizerLip.addTexture("deskrim.jpg");
	deskOrganizerLip.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(0.1f, 0.1f, 0.1f), 8);

	deskOrganizerInsert.createShape(deskOrganizerInsertV, deskOrganizerInsertI, transformLocation, transform);
	deskOrganizerInsert.setPosition(-12.0f, 2.0f, -12.0f);
	deskOrganizerInsert.setScale(2.0f, 2.0f, 2.0f);
	deskOrganizerInsert.setRotation(-90.0f, 1.0f, 0.0f, 0.0f);
	deskOrganizerInsert.addTexture("grayplastic.jpg");
	deskOrganizerInsert.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(0.1f, 0.1f, 0.1f), 8);


	std::vector<float> chargerBankV = {
		// Front face
		-1.0f, 1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 1.0f,		// top left
		1.0f, 1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	1.0f, 1.0f,		// top right
		1.0f, -1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	1.0f, 0.0f,		// bottom right
		-1.0f, -1.0f, 1.0f,		0.0f, 0.0f, 1.0f,	0.0f, 0.0f,		// bottom left

		// Back face
		-1.0f, 1.0f, -1.0f,		0.0f, 0.0f, -1.0f,	1.0f, 1.0f,		// top left
		1.0f, 1.0f, -1.0f,		0.0f, 0.0f, -1.0f,	0.0f, 1.0f,		// top right
		1.0f, -1.0f, -1.0f,		0.0f, 0.0f, -1.0f,	0.0f, 0.0f,		// bottom right
		-1.0f, -1.0f, -1.0f,	0.0f, 0.0f, -1.0f,	1.0f, 0.0f,		// bottom left

		// Right face
		1.0f, 1.0f, 1.0f,		1.0f, 0.0f,	0.0f,	0.0f, 1.0f,		// near top
		1.0f, 1.0f, -1.0f,		1.0f, 0.0f,	0.0f,	1.0f, 1.0f,		// far top
		1.0f, -1.0f, -1.0f,		1.0f, 0.0f,	0.0f,	1.0f, 0.0f,		// far bottom
		1.0f, -1.0f, 1.0f,		1.0f, 0.0f,	0.0f,	0.0f, 0.0f,		// near bottom

		// Left face
		-1.0f, 1.0f, 1.0f,		-1.0f, 0.0f, 0.0f,	0.0f, 1.0f,		// near top
		-1.0f, 1.0f, -1.0f,		-1.0f, 0.0f, 0.0f,	1.0f, 1.0f,		// far top
		-1.0f, -1.0f, -1.0f,	-1.0f, 0.0f, 0.0f,	1.0f, 0.0f,		// far bottom
		-1.0f, -1.0f, 1.0f,		-1.0f, 0.0f, 0.0f,	0.0f, 0.0f,		// near bottom

		// Top face
		-1.0f, 1.0f, 1.0f,		0.0f, 1.0f,	0.0f,	0.0f, 1.0f,		// far left
		1.0f, 1.0f, 1.0f,		0.0f, 1.0f,	0.0f,	1.0f, 1.0f,		// far right
		1.0f, 1.0f, -1.0f,		0.0f, 1.0f,	0.0f,	1.0f, 0.0f,		// near right
		-1.0f, 1.0f, -1.0f,		0.0f, 1.0f,	0.0f,	0.0f, 0.0f,		// near left

		// Bottom face
		-1.0f, -1.0f, 1.0f,		0.0f, -1.0f, 0.0f,	0.0f, 1.0f,		// far left
		1.0f, -1.0f, 1.0f,		0.0f, -1.0f, 0.0f,	1.0f, 1.0f,		// far right
		1.0f, -1.0f, -1.0f,		0.0f, -1.0f, 0.0f,	1.0f, 0.0f,		// near right
		-1.0f, -1.0f, -1.0f,	0.0f, -1.0f, 0.0f,	0.0f, 0.0f,		// near left
	};

	std::vector<unsigned int> chargerBankI = {
		0,1,2,
		0,2,3,

		4,5,6,
		4,6,7,

		8,9,10,
		8,10,11,

		12,13,14,
		12,14,15,

		16,17,18,
		16,18,19,

		20,21,22,
		20,22,23,
	};

	chargerBank.createShape(chargerBankV, chargerBankI, transformLocation, transform);
	chargerBank.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), 256);
	//cube.setScale(3.0f, 3.0f, 3.0f);
	chargerBank.addTexture("chargerbank.jpg");
	chargerBank.setPosition(-10.0f, 0.5f, 10.0f);
	chargerBank.setScale(8.0f, 0.5f, 5.0f);
	chargerBank.setRotation(-30.0f, 0.0f, 1.0f, 0.0f);


	std::vector<float> cupBodyV = {
		// Front - index 8
		-0.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,		0.25f, 1.0f,
		0.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,		0.75f, 1.0f,
		1.0f, 0.5f, 0.0f,		0.0f, 1.0f, 0.0f,		1.0f, 0.75f,
		1.0f, -0.5f, 0.0f,		1.0f, 0.0f, 0.0f,		1.0f, 0.25f,
		0.5f, -1.0f, 0.0f,		1.0f, 0.0f, 0.0f,		0.75f, 0.0f,
		-0.5f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,		0.25f, 0.0f,
		-1.0f, -0.5f, 0.0f,		0.0f, -1.0f, 0.0f,		0.0f, 0.25f,
		-1.0f, 0.5f, 0.0f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.75f,

		// Back - index 8
		-0.5f, 1.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.25f, 1.0f,
		0.5f, 1.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.75f, 1.0f,
		1.0f, 0.5f, -1.0f,		0.0f, 1.0f, 0.0f,		1.0f, 0.75f,
		1.0f, -0.5f, -1.0f,		1.0f, 0.0f, 0.0f,		1.0f, 0.25f,
		0.5f, -1.0f, -1.0f,		1.0f, 0.0f, 0.0f,		0.75f, 0.0f,
		-0.5f, -1.0f, -1.0f,	0.0f, -1.0f, 0.0f,		0.25f, 0.0f,
		-1.0f, -0.5f, -1.0f,	0.0f, -1.0f, 0.0f,		0.0f, 0.25f,
		-1.0f, 0.5f, -1.0f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.75f,

		// Cup bottom
		0.0f, 0.0f, -1.0f,		0.0f, 0.0f, -1.0f,		0.0f, 0.0f,

	};

	std::vector<unsigned int> cupBodyI = {
		// Top edge
		0,1,8,
		8,9,1,

		// Upper Right
		1,2,9,
		9,10,2,

		// Right
		2,3,10,
		10,11,3,

		// Lower right
		3,4,11,
		11,12,4,

		// Bottom
		4,5,12,
		12,13,5,

		// Lower left
		5,6,13,
		13,14,6,

		// Left
		6,7,14,
		14,15,7,

		// Lower left
		7,0,15,
		15,8,0,

		// Cup bottom
		16,8,9,
		16,9,10,
		16,10,11,
		16,11,12,
		16,12,13,
		16,13,14,
		16,14,15,
		16,15,8,
	};

	std::vector<float> cupLipV = {
		// Front - index 8
		-0.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,		0.25f, 1.0f,
		0.5f, 1.0f, 0.0f,		0.0f, 1.0f, 0.0f,		0.75f, 1.0f,
		1.0f, 0.5f, 0.0f,		0.0f, 1.0f, 0.0f,		1.0f, 0.75f,
		1.0f, -0.5f, 0.0f,		1.0f, 0.0f, 0.0f,		1.0f, 0.25f,
		0.5f, -1.0f, 0.0f,		1.0f, 0.0f, 0.0f,		0.75f, 0.0f,
		-0.5f, -1.0f, 0.0f,		0.0f, -1.0f, 0.0f,		0.25f, 0.0f,
		-1.0f, -0.5f, 0.0f,		0.0f, -1.0f, 0.0f,		0.0f, 0.25f,
		-1.0f, 0.5f, 0.0f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.75f,

		// Back - index 8
		-0.5f, 1.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.25f, 1.0f,
		0.5f, 1.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.75f, 1.0f,
		1.0f, 0.5f, -1.0f,		0.0f, 1.0f, 0.0f,		1.0f, 0.75f,
		1.0f, -0.5f, -1.0f,		1.0f, 0.0f, 0.0f,		1.0f, 0.25f,
		0.5f, -1.0f, -1.0f,		1.0f, 0.0f, 0.0f,		0.75f, 0.0f,
		-0.5f, -1.0f, -1.0f,	0.0f, -1.0f, 0.0f,		0.25f, 0.0f,
		-1.0f, -0.5f, -1.0f,	0.0f, -1.0f, 0.0f,		0.0f, 0.25f,
		-1.0f, 0.5f, -1.0f,		-1.0f, 0.0f, 0.0f,		0.0f, 0.75f,


	};

	std::vector<unsigned int> cupLipI = {
		// Top edge
		0,1,8,
		8,9,1,

		// Upper Right
		1,2,9,
		9,10,2,

		// Right
		2,3,10,
		10,11,3,

		// Lower right
		3,4,11,
		11,12,4,

		// Bottom
		4,5,12,
		12,13,5,

		// Lower left
		5,6,13,
		13,14,6,

		// Left
		6,7,14,
		14,15,7,

		// Lower left
		7,0,15,
		15,8,0,
	};

	cupBody.createShape(cupBodyV, cupBodyI, transformLocation, transform);
	cupBody.setPosition(10.0f, 4.3f, 12.0f);
	cupBody.setRotation(-25.0f, 0.0f, 1.0f, 0.0f);
	cupBody.setScale(4.0f, 4.0f, 10.0f);
	cupBody.addTexture("cup.jpg");
	cupBody.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), 256);

	cupLip.createShape(cupLipV, cupLipI, transformLocation, transform);
	cupLip.setPosition(10.0f, 4.3f, 12.0f);
	cupLip.setRotation(-25.0f, 0.0f, 1.0f, 0.0f);
	cupLip.setScale(4.1f, 4.1f, 2.0f);
	cupLip.addTexture("cup2.jpg");
	cupLip.addMaterial(shaderProgram[0], glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), 256);

}

void OpenGL::createLights() {
	std::vector<float> lightCubeVertices = {
		// Front face
		-1.0f, 1.0f, 1.0f,			// top left
		1.0f, 1.0f, 1.0f,			// top right
		1.0f, -1.0f, 1.0f,			// bottom right
		-1.0f, -1.0f, 1.0f,			// bottom left

		// Back face
		-1.0f, 1.0f, -1.0f,			// top left
		1.0f, 1.0f, -1.0f,			// top right
		1.0f, -1.0f, -1.0f,			// bottom right
		-1.0f, -1.0f, -1.0f,		// bottom left

		// Right face
		1.0f, 1.0f, 1.0f,			// near top
		1.0f, 1.0f, -1.0f,			// far top
		1.0f, -1.0f, -1.0f,			// far bottom
		1.0f, -1.0f, 1.0f,			// near bottom

		// Left face
		-1.0f, 1.0f, 1.0f,			// near top
		-1.0f, 1.0f, -1.0f,			// far top
		-1.0f, -1.0f, -1.0f,		// far bottom
		-1.0f, -1.0f, 1.0f,			// near bottom

		// Top face
		-1.0f, 1.0f, 1.0f,			// far left
		1.0f, 1.0f, 1.0f,			// far right
		1.0f, 1.0f, -1.0f,			// near right
		-1.0f, 1.0f, -1.0f,			// near left

		// Bottom face
		-1.0f, -1.0f, 1.0f,			// far left
		1.0f, -1.0f, 1.0f,			// far right
		1.0f, -1.0f, -1.0f,			// near right
		-1.0f, -1.0f, -1.0f,		// near left
	};

	std::vector<unsigned int> lightCubeIndices = {
		0,1,2,
		0,2,3,

		4,5,6,
		4,6,7,

		8,9,10,
		8,10,11,

		12,13,14,
		12,14,15,

		16,17,18,
		16,18,19,

		20,21,22,
		20,22,23,
	};
	
	light[0].createLight(lightCubeVertices, lightCubeIndices, transformLocation, transform, glm::vec3(1.0f, 0.5f, 0.2f));
	light[0].setLighting(shaderProgram[0], glm::vec3(0.1f, 0.1f, 0.1f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(0.5f, 0.5f, 0.5f), 1.0f, 0.09f, 0.032f);
	light[0].setPosition(-10.0f, 15.0f, -4.0f);
	light[0].setType(Light::POINT);
	
	light[1].createLight(lightCubeVertices, lightCubeIndices, transformLocation, transform, glm::vec3(1.0f, 0.0f, 0.0f));
	light[1].setLighting(shaderProgram[0], glm::vec3(0.2f, 0.1f, 0.05f), glm::vec3(0.5f, 0.25f, 0.13f), glm::vec3(0.2f, 0.1f, 0.05f), 1.0f, 0.09f, 0.032f);
	light[1].setDirection(glm::vec3(-1.0f, -1.0f, 0.0f));
	light[1].setType(Light::DIRECTIONAL);
	light[1].setPosition(-10.0f, 10.0f, -2.0f);
	//light[1].setRotation(60.0f, 0.0f, 0.0f, 1.0f);

	
	light[2].createLight(lightCubeVertices, lightCubeIndices, transformLocation, transform, glm::vec3(0.0f, 0.0f, 1.0f));
	light[2].setLighting(shaderProgram[0], glm::vec3(0.0f, 0.0f, 0.1f), glm::vec3(0.0f, 0.0f, 1.0f), glm::vec3(0.0f, 0.0f, 1.0f), 1.0f, 0.09f, 0.032f);
	light[2].setDirection(glm::vec3(1.0f, 0.0f, 0.0f));
	light[2].setType(Light::POINT);
	light[2].setPosition(0.0f, 5.0f, -10.0f);
	

	//light[0].createLight(lightCubeVertices, lightCubeIndices, lightTransformLocation, transform, glm::vec3(1.0f, 1.0f, 1.0f));



}