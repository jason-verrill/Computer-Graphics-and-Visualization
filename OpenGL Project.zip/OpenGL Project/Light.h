#ifndef LIGHT_H
#define LIGHT_H

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>

class Light {
public:
	enum TYPE {
		POINT,
		DIRECTIONAL,
		SPOTLIGHT
	};

	struct Lighting {
		glm::vec3 position;
		glm::vec3 direction;
		glm::vec3 ambient;
		glm::vec3 diffuse;
		glm::vec3 specular;
		float constant;
		float linear;
		float quadratic;

		unsigned int positionShader;
		unsigned int ambientShader;
		unsigned int diffuseShader;
		unsigned int specularShader;
		unsigned int constantShader;
		unsigned int linearShader;
		unsigned int quadraticShader;
	};

	void createLight(std::vector<float> vertexData, std::vector<unsigned int> indexData, unsigned int transformShaderLocation, glm::mat4& transformMatrix, glm::vec3 lightColor);
	void render();
	void setPosition(float x, float y, float z);
	void setRotation(float degrees, float x, float y, float z);
	void setScale(float x, float y, float z);
	glm::vec3 getPosition();
	glm::mat4 getPositionMatrix();
	glm::vec3 getColor();
	bool getIsOn();
	void setIsOn(bool state);
	void toggle();
	void setColor(glm::vec3 lightColor);
	void setDirection(glm::vec3 lightDirection);
	glm::vec3 getDirection();
	void setType(TYPE type);
	TYPE getType(); 
	glm::vec3 getAmbient();
	glm::vec3 getDiffuse();
	glm::vec3 getSpecular();
	void setLighting(unsigned int shaderProgram, glm::vec3 ambientLight, glm::vec3 diffuseLight, glm::vec3 specularLight, float constant, float linear, float quadratic);
	void updateShader();
	float getConstant();
	float getLinear();
	float getQuadratic();
private:
	unsigned int vertexArray;
	unsigned int vertexBuffer;
	unsigned int elementBuffer;
	unsigned int transformShader;
	std::vector<float> vertices;
	std::vector<unsigned int> indices;
	glm::mat4 rotation;
	glm::mat4 position;
	glm::vec3 positionVec;
	glm::mat4 scale;
	glm::mat4* transform;
	glm::vec3 color;
	bool isOn;
	TYPE type;
	Lighting light;
};

#endif