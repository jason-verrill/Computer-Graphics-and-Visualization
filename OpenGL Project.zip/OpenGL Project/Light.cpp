#include "light.h"

void Light::createLight(std::vector<float> vertexData, std::vector<unsigned int> indexData, unsigned int shaderProgram, glm::mat4& transformMatrix, glm::vec3 lightColor) {
	// Set base transform
	rotation = glm::mat4(1.0f);
	position = glm::mat4(1.0f);
	scale = glm::mat4(1.0f);
	transformShader = glGetUniformLocation(shaderProgram, "transform");
	light.positionShader = glGetUniformLocation(shaderProgram, "light.position");
	light.position = glm::vec3(0.0f, 0.0f, 0.0);

	transform = &transformMatrix;
	isOn = true;

	// Copy vertex and index data
	vertices = vertexData;
	indices = indexData;

	// Create VAO and buffers
	glGenVertexArrays(1, &vertexArray);
	glGenBuffers(1, &vertexBuffer);
	glGenBuffers(1, &elementBuffer);

	// Activate VAO and bind buffers
	glBindVertexArray(vertexArray);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBuffer);

	// Draw data onto buffers
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_STATIC_DRAW);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);

	// Tell OpenGL how vertex data is arranged and enable attributes
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	color = lightColor;
}

void Light::render() {
	*transform = position * rotation * scale;
	glBindVertexArray(vertexArray);
	glUniformMatrix4fv(transformShader, 1, GL_FALSE, glm::value_ptr(*transform));
	glUniform3fv(light.positionShader, 1, glm::value_ptr(light.position));
	//glUniform3fv(light.positionShader, 1, glm::value_ptr(light.position));
	//glUniform3fv(light.ambientShader, 1, glm::value_ptr(light.ambient));
	//glUniform3fv(light.diffuseShader, 1, glm::value_ptr(light.diffuse));
	//glUniform3fv(light.specularShader, 1, glm::value_ptr(light.specular));
	
	
	glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, (void*)0);
}

void Light::updateShader() {
	*transform = position * rotation * scale;
	glBindVertexArray(vertexArray);
	glUniformMatrix4fv(transformShader, 1, GL_FALSE, glm::value_ptr(*transform));
	glUniform3fv(light.positionShader, 1, glm::value_ptr(light.position));
	glUniform3fv(light.ambientShader, 1, glm::value_ptr(light.ambient));
	glUniform3fv(light.diffuseShader, 1, glm::value_ptr(light.diffuse));
	glUniform3fv(light.specularShader, 1, glm::value_ptr(light.specular));
}

void Light::setPosition(float x, float y, float z) {
	light.position += glm::vec3(x, y, z);
}

void Light::setRotation(float degrees, float x, float y, float z) {
	rotation = glm::rotate(rotation, glm::radians(degrees), glm::vec3(x, y, z));
}

void Light::setScale(float x, float y, float z) {
	scale = glm::scale(scale, glm::vec3(x, y, z));
}

glm::vec3 Light::getPosition() {
	return light.position;
}

glm::mat4 Light::getPositionMatrix() {
	return glm::translate(position, light.position);
}

glm::vec3 Light::getColor() {
	if (isOn) {
		return color;
	}
	else {
		return glm::vec3(0.0f, 0.0f, 0.0f);
	}
}

bool Light::getIsOn() {
	return isOn;
}

void Light::setIsOn(bool state) {
	isOn = state;
}

void Light::toggle() {
	isOn = !isOn;
}

void Light::setColor(glm::vec3 lightColor) {
	color = lightColor;
}

void Light::setDirection(glm::vec3 lightDirection) {
	light.direction += lightDirection;
}

glm::vec3 Light::getDirection() {
	return light.direction;
}

void Light::setType(Light::TYPE lightType) {
}

Light::TYPE Light::getType() {
	return type;
}

glm::vec3 Light::getAmbient() {
	return light.ambient;
}

glm::vec3 Light::getDiffuse() {
	return light.diffuse;
}

glm::vec3 Light::getSpecular() {
	return light.specular;
}

float Light::getConstant() {
	return light.constant;
}

float Light::getLinear() {
	return light.linear;
}

float Light::getQuadratic() {
	return light.quadratic;
}


void Light::setLighting(unsigned int shaderProgram, glm::vec3 ambientLight, glm::vec3 diffuseLight, glm::vec3 specularLight, float constant, float linear, float quadratic) {
	light.ambient = ambientLight;
	light.diffuse = diffuseLight;
	light.specular = specularLight;

	light.ambientShader = glGetUniformLocation(shaderProgram, "light.ambient");
	light.diffuseShader = glGetUniformLocation(shaderProgram, "light.diffuse");
	light.specularShader = glGetUniformLocation(shaderProgram, "light.specular");
}