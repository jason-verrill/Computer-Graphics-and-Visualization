#version 330 core

struct Material {
	sampler2D diffuse;
	//vec3 ambient;
	//vec3 diffuse;
	sampler2D specular;
	float shininess;
};

struct Light {
	vec3 position;
	vec3 direction;
	vec3 ambient;
	vec3 diffuse;
	vec3 specular;

	float constant;
	float linear;
	float quadratic;
};

uniform Material material;
uniform Light light[3];

uniform vec3 lightColor;

uniform sampler2D tex;

uniform vec3 camPosition;

in vec3 Normal;
in vec3 FragPos;
in vec2 TexCoord;

out vec4 FragColor;



vec3 CalcDirLight(Light light, vec3 normal, vec3 viewDir) {
	vec3 lightDir = normalize(-light.direction);

    // diffuse shading
    float diff = max(dot(normal, lightDir), 0.0);

    // specular shading
    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);

    // combine results
    vec3 ambient = light.ambient * vec3(texture(material.diffuse, TexCoord));
    vec3 diffuse = light.diffuse * diff * vec3(texture(material.diffuse, TexCoord));
    vec3 specular = light.specular * spec * vec3(texture(material.specular, TexCoord));
    return (ambient + diffuse + specular);
}

vec3 CalcPointLight(Light light, vec3 normal, vec3 fragPos, vec3 viewDir) {
	vec3 lightDir = normalize(light.position - fragPos);

    // diffuse shading
    float diff = max(dot(normal, lightDir), 0.0);

    // specular shading
    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);

	float distance = length(light.position - fragPos);
	float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));

    // combine results
    vec3 ambient = light.ambient * vec3(texture(material.diffuse, TexCoord));
    vec3 diffuse = light.diffuse * diff * vec3(texture(material.diffuse, TexCoord));
    vec3 specular = light.specular * spec * vec3(texture(material.specular, TexCoord));

	//ambient *= attenuation;
	//diffuse *= attenuation;
	//specular *= attenuation;

    return (ambient + diffuse + specular);
}

void main() {
	vec3 norm = normalize(Normal);
	vec3 viewDirection = normalize(camPosition - FragPos);

	vec3 result = vec3(0.0, 0.0, 0.0);
	
	result += CalcPointLight(light[0], norm, FragPos, viewDirection);
	result += CalcPointLight(light[2], norm, FragPos, viewDirection);

	result += CalcDirLight(light[1], norm, viewDirection);
	

	FragColor = vec4(result, 1.0);




	/*
	// Ambient
	vec3 ambient = light[1].ambient * vec3(texture(material.diffuse, TexCoord));
	
	// Diffuse
	vec3 norm = normalize(Normal);

	//vec3 lightDir = normalize(light[1].position - FragPos);
	vec3 lightDir = normalize(-light[1].direction);

	float diffuseCalc = max(dot(norm, lightDir), 0.0);
	vec3 diffuse = light[1].diffuse * diffuseCalc * vec3(texture(material.diffuse, TexCoord));

	// Specular
	vec3 viewDirection = normalize(camPosition - FragPos);
	vec3 reflectDirection = reflect(-lightDir, norm);
	float specularCalc = pow(max(dot(viewDirection, reflectDirection), 0.0), material.shininess);
	//vec3 specular = light[1].specular * (specularCalc * material.specular);
	vec3 specular = light[1].specular * specularCalc * vec3(texture(material.specular, TexCoord));

	// Combined
	vec3 result = ambient + diffuse + specular;
	FragColor = vec4(result, 1.0);
	*/
}

