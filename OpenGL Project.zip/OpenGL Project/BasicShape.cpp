#include "BasicShape.h"

void BasicShape::createShape(std::vector<float> vertexData, std::vector<unsigned int> indexData, unsigned int modelSpaceShaderLocation, glm::mat4 &modelSpaceMatrix) {
	// Initial texture data
	hasTexture = false;
	hasMaterial = false;
	textures.resize(1);
	textureIndexOffset.resize(1);

	// Set base transform
	rotation = glm::mat4(1.0f);
	position = glm::mat4(1.0f);
	scale = glm::mat4(1.0f);
	transformLocation = modelSpaceShaderLocation;
	transform = &modelSpaceMatrix;

	// Copy vertex and index data
	vertices = vertexData;
	indices = indexData;

	// Create VAO and buffers
	glGenVertexArrays(1, &vertexArray);
	glGenBuffers(1, &vertexBuffer);
	glGenBuffers(1, &elementBuffer);

	// Activate VAO and bind buffers
	glBindVertexArray(vertexArray);
	glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBuffer);

	// Draw data onto buffers
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_STATIC_DRAW);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);

	// Tell OpenGL how vertex data is arranged and enable attributes
	// Vertices
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// Color
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// Texture coordinates
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);
}


/*
void BasicShape::addTexture(const char* filename, unsigned int startingIndexLocation) {
	// Texture variables
	int textureWidth;
	int textureHeight;
	int nrChannels;
	unsigned char* textureData;

	// Increase texture size
	textures.resize(textures.size() + 1);
	textureIndexOffset.resize(textureIndexOffset.size() + 1);


	// ...unless this is the first texture
	if (!hasTexture) {
		hasTexture = true;
		textures.resize(1);
		textureIndexOffset.resize(1);
	}

	// Set texture index starting location
	textureIndexOffset.at(textureIndexOffset.size() - 1) = startingIndexLocation;



	textureData = stbi_load(filename, &textureWidth, &textureHeight, &nrChannels, 0);

	// Generate texture object
	std::cout << "Generating texture at: " << textures.size() - 1 << std::endl;
	glGenTextures(1, &textures.at(textures.size() - 1));
	glBindTexture(GL_TEXTURE_2D, textures.at(textures.size() - 1));

	// Set texture options
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// Fill texture object
	if (textureData) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, textureWidth, textureHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, textureData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		std::cout << "Failed to load texture." << std::endl;
	}
		
	// Clean up
	stbi_image_free(textureData);
}

void BasicShape::draw() {
	// Set transform
	*modelSpace = position * rotation * scale;
	glUniformMatrix4fv(modelSpaceLocation, 1, GL_FALSE, glm::value_ptr(*modelSpace));

	//std::cout << "textures: " << textures.size() << std::endl;

	//glBindTexture(GL_TEXTURE_2D, textures.at(0));
	//glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, (void*)0);

	//glBindTexture(GL_TEXTURE_2D, textures.at(1));
	//glDrawElements(GL_TRIANGLES, indices.size() - 7, GL_UNSIGNED_INT, (void*)indices[6]);


	// Activate the VAO
	glBindVertexArray(vertexArray);
	
	//std::cout << "Number of textures: " << textures.size() << std::endl;
	//std::cout << "Number of indices: " << indices.size() << std::endl << std::endl;
	
	// Select textures at the appropriate index locations, then draw the vertices
	for (int i = 0; i < textures.size(); i++) {
		//std::cout << "Iteration: " << i << std::endl;
		glBindTexture(GL_TEXTURE_2D, textures.at(i));

		// If there is only 1 texture...
		if (i == 0 && textures.size() == 1) {
			//std::cout << "1. Number of indices: " << indices.size() << std::endl;
			glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, (void*)0);
		}
		// If there is another texture to draw...
		else if (i + 1 < textures.size()) {
			// The total indices to draw is the next texture's index offset
			glDrawElements(GL_TRIANGLES, textureIndexOffset.at(i + 1), GL_UNSIGNED_INT, (void*)indices[textureIndexOffset.at(i)]);

			//std::cout << "2. Number of indices: " << textureIndexOffset.at(i + 1) << std::endl;
			//std::cout << "Offset location: " << textureIndexOffset.at(i) << std::endl;
		}
		// If this is the last texture to draw...
		else if (i == textures.size() - 1) {
			glDrawElements(GL_TRIANGLES, indices.size() - textureIndexOffset.at(i), GL_UNSIGNED_INT, (void*)indices[textureIndexOffset.at(i)]);

			//std::cout << "3. Number of indices: " << indices.size() - textureIndexOffset.at(i) << std::endl;
			//std::cout << "Offset location: " << textureIndexOffset.at(i) << std::endl;
		}
		std::cout << std::endl;
	}
}
*/

void BasicShape::setPosition(float x, float y, float z) {
	position = glm::translate(position, glm::vec3(x, y, z));
}

void BasicShape::setRotation(float degrees, float x, float y, float z) {
	rotation = glm::rotate(rotation, glm::radians(degrees), glm::vec3(x, y, z));
}

void BasicShape::setScale(float x, float y, float z) {
	scale = glm::scale(scale, glm::vec3(x, y, z));
}

void BasicShape::setModelSpace(unsigned int transformShaderLocation, glm::mat4* transformMatrix) {
	transformLocation = transformShaderLocation;
	transform = transformMatrix;
}


void BasicShape::addTexture(const char* filename, unsigned int startingIndexLocation) {
	int textureWidth;
	int textureHeight;
	int nrChannels;
	unsigned char* textureData;

	if (!hasTexture) {
		textures.resize(1);
		textureIndexOffset.resize(1);
		textureIndexOffset.at(0) = 0;
		hasTexture = true;
	}
	else {
		// Increase size
		textures.resize(textures.size() + 1);
		textureIndexOffset.resize(textureIndexOffset.size() + 1);

		// Set starting index for this texture
		textureIndexOffset.at(textureIndexOffset.size() - 2) = startingIndexLocation;
	}

	// Generate and add texture to end of texture list
	glGenTextures(1, &textures.at(textures.size() - 1));
	glBindTexture(GL_TEXTURE_2D, textures.at(textures.size() - 1));

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);


	textureData = stbi_load(filename, &textureWidth, &textureHeight, &nrChannels, 0);

	if (textureData) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, textureWidth, textureHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, textureData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}

	stbi_image_free(textureData);
}

void BasicShape::addMaterial(unsigned int shaderProgram, glm::vec3 ambientLight, glm::vec3 diffuseLight, glm::vec3 specularLight, float objectShininess) {
	material.ambient = ambientLight;
	material.diffuse = diffuseLight;
	material.specular = specularLight;
	material.shininess = objectShininess;

	hasMaterial = true;

	//material.ambientLocation = glGetUniformLocation(shaderProgram, "material.ambient");
	material.diffuseLocation = glGetUniformLocation(shaderProgram, "material.diffuse");
	material.specularLocation = glGetUniformLocation(shaderProgram, "material.specular");
	material.shininessLocation = glGetUniformLocation(shaderProgram, "material.shininess");
}

void BasicShape::draw() {
	*transform = position * rotation * scale;
	glBindVertexArray(vertexArray);
	glUniformMatrix4fv(transformLocation, 1, GL_FALSE, glm::value_ptr(*transform));
	//glUniform3fv(material.ambientLocation, 1, glm::value_ptr(material.ambient));
	//glUniform3fv(material.diffuseLocation, 1, glm::value_ptr(material.diffuse));
	glUniform1i(material.diffuseLocation, 0);
	glUniform3fv(material.specularLocation, 1, glm::value_ptr(material.specular));
	glUniform1f(material.shininessLocation, material.shininess);
	

	//glBindTexture(GL_TEXTURE_2D, textures.at(0));
	//glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, (void*)0);

	//glBindTexture(GL_TEXTURE_2D, textures.at(1));
	//glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, (void*)(3*sizeof(unsigned int)));



	if (hasTexture) {
		// Set texture, draw from indices until offset, then repeat for each texture
		glBindTexture(GL_TEXTURE_2D, textures.at(0));
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, (void*)0);

	}
	/*if (hasTexture) {
		// Set texture, draw from indices until offset, then repeat for each texture
		for (int i = 0; i < textures.size(); i++) {
			glBindTexture(GL_TEXTURE_2D, textures.at(i));
			glDrawElements(GL_TRIANGLES, indices.size() - textureIndexOffset.at(i), GL_UNSIGNED_INT, (void*)(textureIndexOffset.at(i) * sizeof(unsigned int)));
		}
	}*/
	else {
		// Unbind whatever previous texture may have been used for some other object, and draw the object
		glBindTexture(GL_TEXTURE_2D, 0);
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, (void*)0);
	}
}